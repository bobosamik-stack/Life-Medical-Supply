Life Medical Supply Super Project

Готовый проект для Netlify.
Главный файл: index.html

Что внутри:
- Красивый сайт Life Medical Supply
- Services
- Documents required
- Office Dashboard demo
- Add/Edit/Delete Patient
- Search
- Status filters
- Reminder date
- CSV export
- Print
- Browser notifications

Важно:
Это демо хранит данные в браузере localStorage.
Не добавляйте настоящих пациентов/medical records без secure server/HIPAA-ready setup.

Netlify:
- Можно загрузить ZIP целиком
- Или загрузить один файл index.html
